CORE -> Android app (PWABuilder)
1. Host this folder over HTTPS (needs a real URL): Netlify Drop, GitHub Pages, Cloudflare Pages, or Render Static Site. Upload index.html, sw.js, manifest.webmanifest and the icons folder as-is.
2. Open pwabuilder.com, paste your URL, Start. It should show manifest + service worker green.
3. Package for stores -> Android -> Generate. Download the zip (APK/AAB + signing key). KEEP the signing key.
4. Install the APK on your phone (allow unknown sources).
Internet: Android apps from PWABuilder include the INTERNET permission automatically; a PWA manifest has no permissions field, so nothing to add. Camera/mic are asked at runtime.
Offline: the app shell + cached libraries open offline; AI chat, image gen and Puter need internet.
